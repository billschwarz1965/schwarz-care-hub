MedVerse Scientific Intelligence Ecosystem v0.4 — Mac Portable Edition
========================================================================

NO INSTALLATION REQUIRED — NO ADMIN RIGHTS NEEDED

Getting Started:
  1. Extract this zip to any location on your Mac
     (Desktop, Documents, Downloads — anywhere)
  2. Double-click "Launch MedVerse.command"
  3. If macOS says it can't be opened because it's from an
     unidentified developer:
       - Right-click the file → Open → click "Open" in the dialog
       - Or: System Settings → Privacy & Security → click "Open Anyway"
  4. MedVerse opens in your default browser at http://localhost:8080

To Stop:
  Press Ctrl+C in the Terminal window, or just close it.

What's Inside:
  - 10 AI-powered modules for MSLs, HCPs, patients, and medical affairs
  - Interactive demos with narrated walkthroughs
  - Master Demo page with one-click Play All mode

Modules:
  - MSL Copilot (13 agents)
  - Medical Concierge (12 agents)
  - HCP Concierge
  - Patient Concierge (11 agents)
  - Orion Intelligence
  - Disease Navigator
  - Literature Intelligence
  - Congress Intelligence
  - Agent Ecosystem
  - Power Agents

Requirements:
  - macOS 10.15+ (Catalina or later)
  - Python 3 (included with macOS)

To Uninstall:
  Just delete this folder. Nothing is written to system folders.

Presented by Bill Schwarz
Digital Product Line & Program Owner
(c) 2025 Sanofi
