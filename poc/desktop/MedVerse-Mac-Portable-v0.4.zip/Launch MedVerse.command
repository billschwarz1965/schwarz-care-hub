#!/bin/bash
# MedVerse Operating System v0.4 — Mac Launcher
# No installation or admin rights required

DIR="$(cd "$(dirname "$0")" && pwd)"
WWW="$DIR/www"
PORT=8080

# Find a free port if 8080 is taken
while lsof -i :$PORT >/dev/null 2>&1; do
    PORT=$((PORT + 1))
    if [ $PORT -gt 8099 ]; then
        echo "Error: Could not find a free port between 8080-8099"
        exit 1
    fi
done

echo ""
echo "  ╔══════════════════════════════════════════╗"
echo "  ║   MedVerse Operating System v0.4         ║"
echo "  ║   Presented by Bill Schwarz              ║"
echo "  ║   Digital Product Line & Program Owner   ║"
echo "  ╚══════════════════════════════════════════╝"
echo ""
echo "  Starting on http://localhost:$PORT"
echo "  Press Ctrl+C to stop"
echo ""

# Open browser after a brief delay
(sleep 1 && open "http://localhost:$PORT/demo.html") &

# Start Python HTTP server (macOS ships with Python 3)
cd "$WWW"
python3 -m http.server $PORT 2>/dev/null || python -m http.server $PORT
